# MongoDB Client Package

## Overview
This package provides an easy-to-use client for MongoDB operations in Python.

## Installation
Install the package using pip:
```bash
pip install .
